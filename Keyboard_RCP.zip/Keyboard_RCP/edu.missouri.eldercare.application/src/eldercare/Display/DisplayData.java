/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package eldercare.Display;

/**
 * 
 * @author Ash
 */
class DisplayData {
	public DisplayData(ElderCareView ed, int[] currentdata, int max,
			double[] dataavg) {
		this.currentdata = currentdata;
		this.ed = ed;
		this.dataavg = dataavg;
		this.max = max;
		Display();
	}

	ElderCareView ed;

	int max = 5;
	// static int [][] datastring;
	static int i = 0;
	// int [] sampledata={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	int[] currentdata = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	// int [] sumdata={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	double[] dataavg = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

	private void Display() {
		org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application
				.getInstance(eldercare.ElderCareApp.class).getContext()
				.getResourceMap(ElderCareView.class);
		for (int k = 0; k < 128; k++) {
			// if(k>25&& k<30)
			// System.out.println(currentdata[k]);

			if (currentdata[k] == 1) {
				ed.rd.sdr.graphdata[k] = ed.rd.sdr.graphdata[k] + 1;
				switch (k) {

				case 0:
					ed.A1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 1:
					ed.A2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 2:
					ed.A3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 3:
					ed.A4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 4:
					ed.A5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 5:
					ed.A6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 6:
					ed.A7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 7:
					ed.A8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 8:
					ed.B1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 9:
					ed.B2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 10:
					ed.B3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 11:
					ed.B4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 12:
					ed.B5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 13:
					ed.B6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 14:
					ed.B7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 15:
					ed.B8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 16:
					ed.C1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 17:
					ed.C2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 18:
					ed.C3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 19:
					ed.C4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 20:
					ed.C5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 21:
					ed.G6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 22:
					ed.C7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 23:
					ed.C8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 24:
					ed.D1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 25:
					ed.D2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 26:
					ed.D3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 27:
					ed.D4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 28:
					ed.D5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 29:
					ed.D6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 30:
					ed.D7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 31:
					ed.D8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 32:
					ed.E1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 33:
					ed.E2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 34:
					ed.E3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 35:
					ed.E4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 36:
					ed.E5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 37:
					ed.E6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 38:
					ed.E7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 39:
					ed.E8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 40:
					ed.F1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 41:
					ed.F2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 42:
					ed.F3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 43:
					ed.F4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 44:
					ed.F5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 45:
					ed.F6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 46:
					ed.F7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 47:
					ed.F8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 48:
					ed.G1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 49:
					ed.G2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 50:
					ed.G3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 51:
					ed.G4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 52:
					ed.G5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 53:
					ed.G6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 54:
					ed.G7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 55:
					ed.G8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 56:
					ed.H1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 57:
					ed.H2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 58:
					ed.H3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 59:
					ed.H4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 60:
					ed.H5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 61:
					ed.H6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 62:
					ed.H7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 63:
					ed.H8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 64:
					ed.I1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 65:
					ed.I2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 66:
					ed.I3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 67:
					ed.I4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 68:
					ed.I5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 69:
					ed.I6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 70:
					ed.I7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 71:
					ed.I8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 72:
					ed.J1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 73:
					ed.J2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 74:
					ed.J3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 75:
					ed.J4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 76:
					ed.J5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 77:
					ed.J6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 78:
					ed.J7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 79:
					ed.J8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 80:
					ed.K1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 81:
					ed.K2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 82:
					ed.K3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 83:
					ed.K4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 84:
					ed.K5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 85:
					ed.K6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 86:
					ed.K7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 87:
					ed.K8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 88:
					ed.L1
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 89:
					ed.L2
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 90:
					ed.L3
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 91:
					ed.L4
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 92:
					ed.L5
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 93:
					ed.L6
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 94:
					ed.L7
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 95:
					ed.L8
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 96:
					ed.A12.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 97:
					ed.B12.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 98:
					ed.C12.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 99:
					ed.D12.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 100:
					ed.E12.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 101:
					ed.F12.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 102:
					ed.G12.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 103:
					ed.H12.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 104:
					ed.A11.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 105:
					ed.B11.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 106:
					ed.C11.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 107:
					ed.D11.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 108:
					ed.E11.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 109:
					ed.F11.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 110:
					ed.G11.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 111:
					ed.H11.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 112:
					ed.A10.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 113:
					ed.B10.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 114:
					ed.C10.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 115:
					ed.D10.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 116:
					ed.E10.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 117:
					ed.F10.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 118:
					ed.G10.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 119:
					ed.H10.setBackground(resourceMap
							.getColor("Data.background"));
					break;
				case 120:
					ed.A9
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 121:
					ed.B9
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 122:
					ed.C9
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 123:
					ed.D9
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 124:
					ed.E9
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 125:
					ed.F9
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 126:
					ed.G9
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;
				case 127:
					ed.H9
							.setBackground(resourceMap
									.getColor("Data.background"));
					break;

				default:
					break;

				}
			} else {
				switch (k) {

				case 0:
					ed.A1.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 1:
					ed.A2.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 2:
					ed.A3.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 3:
					ed.A4.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 4:
					ed.A5.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 5:
					ed.A6.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 6:
					ed.A7.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 7:
					ed.A8.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 8:
					ed.B1.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 9:
					ed.B2.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 10:
					ed.B3.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 11:
					ed.B4.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 12:
					ed.B5.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 13:
					ed.B6.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 14:
					ed.B7.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 15:
					ed.B8.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 16:
					ed.C1.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 17:
					ed.C2.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 18:
					ed.C3.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 19:
					ed.C4.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 20:
					ed.C5.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 21:
					ed.G6.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 22:
					ed.C7.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 23:
					ed.C8.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 24:
					ed.D1.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 25:
					ed.D2.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 26:
					ed.D3.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 27:
					ed.D4.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 28:
					ed.D5.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 29:
					ed.D6.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 30:
					ed.D7.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 31:
					ed.D8.setBackground(resourceMap.getColor("A1.background"));
					break;
				case 32:
					ed.E1.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 33:
					ed.E2.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 34:
					ed.E3.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 35:
					ed.E4.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 36:
					ed.E5.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 37:
					ed.E6.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 38:
					ed.E7.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 39:
					ed.E8.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 40:
					ed.F1.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 41:
					ed.F2.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 42:
					ed.F3.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 43:
					ed.F4.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 44:
					ed.F5.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 45:
					ed.F6.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 46:
					ed.F7.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 47:
					ed.F8.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 48:
					ed.G1.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 49:
					ed.G2.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 50:
					ed.G3.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 51:
					ed.G4.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 52:
					ed.G5.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 53:
					ed.G6.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 54:
					ed.G7.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 55:
					ed.G8.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 56:
					ed.H1.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 57:
					ed.H2.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 58:
					ed.H3.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 59:
					ed.H4.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 60:
					ed.H5.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 61:
					ed.H6.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 62:
					ed.H7.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 63:
					ed.H8.setBackground(resourceMap.getColor("F1.background"));
					break;
				case 64:
					ed.I1.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 65:
					ed.I2.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 66:
					ed.I3.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 67:
					ed.I4.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 68:
					ed.I5.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 69:
					ed.I6.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 70:
					ed.I7.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 71:
					ed.I8.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 72:
					ed.J1.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 73:
					ed.J2.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 74:
					ed.J3.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 75:
					ed.J4.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 76:
					ed.J5.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 77:
					ed.J6.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 78:
					ed.J7.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 79:
					ed.J8.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 80:
					ed.K1.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 81:
					ed.K2.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 82:
					ed.K3.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 83:
					ed.K4.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 84:
					ed.K5.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 85:
					ed.K6.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 86:
					ed.K7.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 87:
					ed.K8.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 88:
					ed.L1.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 89:
					ed.L2.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 90:
					ed.L3.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 91:
					ed.L4.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 92:
					ed.L5.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 93:
					ed.L6.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 94:
					ed.L7.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 95:
					ed.L8.setBackground(resourceMap.getColor("K6.background"));
					break;
				case 96:
					ed.A12.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 97:
					ed.B12.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 98:
					ed.C12.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 99:
					ed.D12.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 100:
					ed.E12.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 101:
					ed.F12.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 102:
					ed.G12.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 103:
					ed.H12.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 104:
					ed.A11.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 105:
					ed.B11.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 106:
					ed.C11.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 107:
					ed.D11.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 108:
					ed.E11.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 109:
					ed.F11.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 110:
					ed.G11.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 111:
					ed.H11.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 112:
					ed.A10.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 113:
					ed.B10.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 114:
					ed.C10.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 115:
					ed.D10.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 116:
					ed.E10.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 117:
					ed.F10.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 118:
					ed.G10.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 119:
					ed.H10.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 120:
					ed.A9.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 121:
					ed.B9.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 122:
					ed.C9.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 123:
					ed.D9.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 124:
					ed.E9.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 125:
					ed.F9.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 126:
					ed.G9.setBackground(resourceMap.getColor("A9.background"));
					break;
				case 127:
					ed.H9.setBackground(resourceMap.getColor("A9.background"));
					break;

				default:
					break;
				}

			}

		}

	}

}
