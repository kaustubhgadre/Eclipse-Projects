/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package eldercare.Display;

import java.util.Hashtable;

/**
 *
 * @author kishor
 */
public  class Enum_hashdata {
    public Hashtable hash = new Hashtable ( 16 );

public void Enum_hashdata()
{
        hash.put ('0' , "0000" );
        hash.put ('1' , "0001" );
        hash.put ('2' , "0010" );
        hash.put ('3' , "0011" );
        hash.put ('4' , "0100" );
        hash.put ('5' , "0101" );
        hash.put ('6' , "0110" );
        hash.put ('7' , "0111" );
        hash.put ('8' , "1000" );
        hash.put ('9' , "1001" );
        hash.put ('A' , "1010" );
        hash.put ('B' , "1011" );
        hash.put ('C' , "1100" );
        hash.put ('D' , "1101" );
        hash.put ('E' , "1110" );
        hash.put ('F' , "1111" );


}






}
