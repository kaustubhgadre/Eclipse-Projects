/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package eldercare.Display;

import gnu.io.UnsupportedCommOperationException;
import java.io.IOException;

/**
 *
 * @author Ash
 */
public class ReadData {
    public Enum_hashdata hashdata;

    public ReadData(ElderCareView ed) throws IOException, UnsupportedCommOperationException {

        this.ed=ed;
        hashdata= new Enum_hashdata();
        try
        {

        sdr=new SerialDataRead(ed);
        }
        catch(Exception e)
        {
            System.out.println("Exception in serial data read "+ e);
        }
        finally
        {
/*   try
          {
            if(sdr.workbook!=null)
            {
        
             sdr.workbook.write();
             sdr.workbook.close();

            }
          }
            catch(Exception e)
            {
                System.out.println("excel file is not opened "+ e);

            }*/

        }
       

    }

    public ElderCareView ed;
    public SerialDataRead sdr;

}
