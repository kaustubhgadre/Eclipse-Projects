/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *
 * PROGRAM EDITED FROM AFTER EXCEL WRITING
 * 03/03/2010
 *
 */

package eldercare.Display;


import gnu.io.CommPortIdentifier;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import gnu.io.UnsupportedCommOperationException;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Locale;
import java.util.TooManyListenersException;

import jxl.CellView;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.format.Alignment;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

/**
 * 
 * @author Ash
 */
class SerialDataRead implements Runnable, SerialPortEventListener {
	static CommPortIdentifier portId;
	static Enumeration portList;

	InputStream inputStream;

	int[][] datastring;

	public SerialDataRead(ElderCareView ed) throws IOException, WriteException {
		this.ed = ed;
		max = ed.maximumframes;
		file = new File(filename);
		wbSettings = new WorkbookSettings();
		wbSettings.setEncoding("UTF-8");
		wbSettings.setLocale(new Locale("en", "EN"));
		// makedefaultcolor();

		workbook = Workbook.createWorkbook(file, wbSettings);
		workbook.createSheet("Report", 0);
		excelSheet = workbook.getSheet(0);
		createLabel(excelSheet);
		workbook.write();
		workbook.close();

		datastring = new int[max][32];
		portList = CommPortIdentifier.getPortIdentifiers();
		Display_data = "";

		System.out.println("in simple read" + portList
				+ portList.hasMoreElements());

		while (portList.hasMoreElements()) {
			System.out.println("in while");
			portId = (CommPortIdentifier) portList.nextElement();
			if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
				if (portId.getName().equals("COM6")) {
					// if (portId.getName().equals("/dev/term/a")) {
					SimpleRead();
				}
			}
		}
	}

	public void SimpleRead() {
		System.out.println("in simple read");

		makedefaultcolor();
		try {
			serialPort = (SerialPort) portId.open("SimpleReadApp", 2000);
		} catch (PortInUseException e) {
			System.out.println(e);
		}
		try {
			inputStream = serialPort.getInputStream();
		} catch (IOException e) {
			System.out.println(e);
		}
		try {
			serialPort.addEventListener(this);
		} catch (TooManyListenersException e) {
			System.out.println(e);
		}
		serialPort.notifyOnDataAvailable(true);
		try {
			serialPort.setSerialPortParams(19200, SerialPort.DATABITS_8,
					SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
		} catch (UnsupportedCommOperationException e) {
			System.out.println(e);
		}

		readThread = new Thread(this);
		readThread.start();

	}

	public void run() {
		while (true) {
			// System.out.println(graphdata[0]+" "+graphdata[1]+" "+zeros[0]);
			// graphdata= zeros;

			System.arraycopy(zeros, 0, zeros, 0, 32);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		}
	};

	public void makedefaultcolor() {

		org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application
				.getInstance(eldercare.ElderCareApp.class).getContext()
				.getResourceMap(ElderCareView.class);
		ed.A1.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.B1.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.C1.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.D1.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.A2.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.B2.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.C2.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.D2.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.A3.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.B3.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.C3.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.D3.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.A4.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.B4.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.C4.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.D4.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.A5.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.B5.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.C5.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.D5.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.A6.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.B6.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.C6.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.D6.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.A7.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.B7.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.C7.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.D7.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.A8.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.B8.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.C8.setBackground(resourceMap.getColor("A1.background")); // NOI18N
		ed.D8.setBackground(resourceMap.getColor("A1.background")); // NOI18N

		ed.E1.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.F1.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.G1.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.H1.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.E2.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.F2.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.G2.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.H2.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.E3.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.F3.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.G3.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.H3.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.E4.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.F4.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.G4.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.H4.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.E5.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.F5.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.G5.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.H5.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.E6.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.F6.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.G6.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.H6.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.E7.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.F7.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.G7.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.H7.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.E8.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.F8.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.G8.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		ed.H8.setBackground(resourceMap.getColor("F1.background")); // NOI18N
		// ed.Cupboard.setBackground(resourceMap.getColor("Data.background"));
		// // NOI18N

		ed.I1.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.J1.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.K1.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.L1.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.I2.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.J2.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.K2.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.L2.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.I3.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.J3.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.K3.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.L3.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.I4.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.J4.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.K4.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.L4.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.I5.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.J5.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.K5.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.L5.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.I6.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.J6.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.K6.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.L6.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.I7.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.J7.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.K7.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.L7.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.I8.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.J8.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.K8.setBackground(resourceMap.getColor("K6.background")); // NOI18N
		ed.L8.setBackground(resourceMap.getColor("K6.background")); // NOI18N

		ed.A9.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.A10.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.A11.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.A12.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.B9.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.B10.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.B11.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.B12.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.C9.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.C10.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.C11.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.C12.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.D9.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.D10.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.D11.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.D12.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.E9.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.E10.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.E11.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.E12.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.F9.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.F10.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.F11.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.F12.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.G9.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.G10.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.G11.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.G12.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.H9.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.H10.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.H11.setBackground(resourceMap.getColor("A9.background")); // NOI18N
		ed.H12.setBackground(resourceMap.getColor("A9.background")); // NOI18N

	}

	public void serialEvent(SerialPortEvent event) {
		// System.out.println("no data"+event.getEventType());

		switch (event.getEventType()) {
		case SerialPortEvent.BI:
		case SerialPortEvent.OE:
		case SerialPortEvent.FE:
		case SerialPortEvent.PE:
		case SerialPortEvent.CD:
		case SerialPortEvent.CTS:
		case SerialPortEvent.DSR:
		case SerialPortEvent.RI:
			System.out.println("carrier not detected");
			break;

		case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
			// No data recieved
			System.out.println("no data");
			break;
		case SerialPortEvent.DATA_AVAILABLE:
			byte[] readBuffer = new byte[8];
			int numBytes = 0;
			try {
				while (inputStream.available() > 0) {
					// System.out.println("near input stream"+ i);
					i++;
					numBytes = inputStream.read(readBuffer);
					// System.out.println("near input stream"+numBytes);
					String data = new String(readBuffer);

					// System.out.print("data "+data+"\n");
					// new DataAnalyze(ed, data);
					// makedefaultcolor();
					analyzeData(data, numBytes);

				}
				// System.out.println("out input stream");

			} catch (IOException e) {
				System.out.println(e);
			}
			break;
		}
	}

	public void analyzeData(String data, int numBytes) {
		for (int n = 0; n < numBytes; n++) {
			char current_data = (char) data.charAt(n);
			ed.status.setText("Status :");
			// System.out.println(current_data+" "+ Display_data);
			if (!data_started) {
				data_ended = false;
				// data_started=true;
				if (Display_data.endsWith("SA")) {
					data_started = true;
					Display_data = "SA";
				} else

					Display_data = Display_data + current_data;
			}

			if (data_started) {
				Display_data = Display_data + current_data;

				if (data_started && !data_ended && Display_data.endsWith("E")) {
					data_started = false;
					data_ended = true;
					System.out.println("data -->" + Display_data + " "
							+ Display_data.length());
					// DisplayData dp = new DisplayData(ed,Display_data);
					AnalyzeData(Display_data);
					Display_data = "";
				} else {
					/*
					 * System.out.println("string not matching "+Display_data);
					 * data_started=false; data_ended=true; Display_data="";
					 */
					if (Display_data.length() > 38)
						System.out.println("String length greater than 26 "
								+ Display_data.length());

				}

			}

			// string_end=false;

		}
		int count = 0;

		// }
		// }
		// int i= (int)c;
		// System.out.println(c+""+m+" "+count);

	}

	public ElderCareView ed;
	boolean lbl1 = false, lbl2 = false, lbl3 = false, lbl4 = false;
	boolean data_started = false;
	boolean data_ended = false;
	public String Display_data;

	int i = 0;
	int max = 150;

	int[] sumdata = new int[128];
	public int[] graphdata = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0 }; //size 128
	public double[] dataavg = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0 }; // size 128
	int[] zeros = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }; //size 128 
	int framecount = 0;

	public void AnalyzeData(String Display_data) {
		// System.out.println(Display_data+" ");
		int[] sampledata = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0 }; // size 128
		int[] currentdata = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0 }; //size 128
		framecount++;
		subtract(sumdata, datastring[0]);
		//int[] sumdata = new int[128];
//		datastring = new int[max][32];
		// System.arraycopy(datastring,1,datastring,0,max-1);

		if (Display_data.equals("SABCDE")) {
			System.out.println("att lit");
			datastring[max - 1] = sampledata;
		} else {
			/*
			 * int aindex= Display_data.indexOf("AA"); int bindex=
			 * Display_data.indexOf("BB"); int cindex=
			 * Display_data.indexOf("CC"); int dindex=
			 * Display_data.indexOf("DD"); int eindex=
			 * Display_data.indexOf("EE");
			 * System.out.println("indices "+aindex+" "
			 * +bindex+" "+cindex+" "+dindex+" "+eindex+" ");
			 */
			int loopcount = 0;
			for (int k = 1; k < Display_data.length(); k++) {
				// k=k+1;
				Integer tempinteger = (int) Display_data.charAt(k);
				char tempchar = Display_data.charAt(k);
				byte[] charbytes;

				// System.out.println(Display_data.length());

				if (Display_data.charAt(k) == 'A'
						|| Display_data.charAt(k) == 'B'
						|| Display_data.charAt(k) == 'C'
						|| Display_data.charAt(k) == 'D') {
					ed.status.setText(ed.status.getText() + " "
							+ Display_data.charAt(k));
					// System.out.println(Display_data.charAt(k));
					continue;

				}
				if (Display_data.charAt(k) == 'E') {
					System.out.println("E");
					k = 100;
					break;
				}
				// System.out.println(k+"---"+Display_data.charAt(k)+" "+loopcount);

				String str1 = Integer.toBinaryString(Display_data.charAt(k));
				// System.out.println(str1.substring(2)+" "+" "+k);
				String str2 = str1.substring(2);
				ed.status.setText(ed.status.getText() + " " + str2);
				for (int innerloop = 0; innerloop < 4; innerloop++) {
					if (loopcount * 4 + innerloop > 127)
						break;
					// System.out.println(str2.charAt(innerloop)+ " "+loopcount+
					// " "+(loopcount*4+innerloop)+" "+innerloop );

					switch (str2.charAt(innerloop)) {

					case '1':
						currentdata[loopcount * 4 + innerloop] = 1;

						// System.out.println(loopcount*4+" "+k);
						break;
					case '0':
						currentdata[loopcount * 4 + innerloop] = 0;

						break;
					default:
						break;
					}

				}
				loopcount++;

			}
			// System.out.println(bindex+" "+cindex+" "+eindex+" "+Display_data+" "+ed.status.getText());

		}

		datastring[max - 1] = currentdata;
		dataavg = addavg(sumdata, currentdata);
		DisplayData a = new DisplayData(ed, currentdata, max, dataavg);
		/*
		 * if(count==100) { count=0; count1++; try { //
		 * addNumber(excelSheet,1,count1,sample); //First time writing header
		 * if(count1==1) { System.out.println("first time "+count1); file = new
		 * File(filename); wbSettings = new WorkbookSettings();
		 * wbSettings.setLocale(new Locale("en", "EN")); workbook =
		 * Workbook.createWorkbook(file, wbSettings); excelSheet
		 * =workbook.createSheet("Report", 0); createLabel(excelSheet);
		 * workbook.write(); workbook.close();
		 * 
		 * }else //there after writing content {
		 * System.out.println("count1 "+count1); file = new File(filename);
		 * System.out.println("count1 384"+count1); tempfile = new
		 * File(tempfilename); System.out.println("count1 386 "+count1);
		 * wbSettings = new WorkbookSettings();
		 * System.out.println("count1 388"+count1); wbSettings.setLocale(new
		 * Locale("en", "EN")); System.out.println("count1 390"+count1); copy =
		 * Workbook.getWorkbook(file); System.out.println("count1 392"+count1);
		 * workbook = Workbook.createWorkbook(tempfile, copy);
		 * System.out.println("count1 394"+count1);
		 * excelSheet=workbook.getSheet(0);
		 * System.out.println("count1 396"+count1);
		 * createLabel1(excelSheet,count1);
		 * System.out.println("count1 398"+count1);
		 * workbook.setOutputFile(file);
		 * System.out.println("count1 400"+count1); workbook.write();
		 * workbook.close();
		 * 
		 * System.out.println("count1 "+count1);
		 * 
		 * }
		 * 
		 * } catch(Exception e) {
		 * System.out.println("Error in writing content "+count1+" "+ e+
		 * file+" "+ workbook+" "+ excelSheet); } graphdata= zeros;
		 * 
		 * }else { count++; }
		 */

	}

	private void subtract(int[] sumdata, int[] i) {
		// System.out.println("in sub avg"+sumdata.length+" "+i.length);
		if (sumdata.length == i.length) {
			for (int j = 0; j < sumdata.length; j++) {
				// System.out.println(sumdata[j]+"  "+i[j]);
				sumdata[j] = sumdata[j] - i[j];
				// System.out.println(sumdata[j]);
			}

		}
		// return sumdata;
	}

	private double[] addavg(int[] sumdata, int[] currentdata) {
		// System.out.println("in adda avg"+sumdata.length+" "+currentdata.length);

		if (sumdata.length == currentdata.length) {
			for (int j = 0; j < currentdata.length; j++) {
				sumdata[j] = sumdata[j] + currentdata[j];
				// System.out.println(sumdata[j]);
				dataavg[j] = (double) (sumdata[j]) / max;
			}

		}
		return dataavg;

	}

	public Thread readThread, writethread;
	public SerialPort serialPort;
	public WriteExcel we;
	public String filename = "c:/temp/eldercare030410_8X4_5sec.xls";
	public String tempfilename = "c:/temp/tempeldercare.xls";
	public int count = 0;
	public int count1 = 0;
	public Integer sample = 1;
	public WritableCellFormat timesBoldUnderline;
	public WritableCellFormat times;

	public WritableWorkbook workbook, workbookcopy;
	public Workbook copy;
	public WritableSheet excelSheet;
	public File file, tempfile;
	public WorkbookSettings wbSettings;

	public void createLabel(WritableSheet sheet) throws WriteException {
		// Lets create a times font
		WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
		// Define the cell format
		times = new WritableCellFormat(times10pt);
		// Lets automatically wrap the cells
		// times.setWrap(true);
		times.setAlignment(Alignment.CENTRE);
		// Create create a bold font with unterlines
		WritableFont times10ptBoldUnderline = new WritableFont(
				WritableFont.TIMES, 10, WritableFont.BOLD, false,
				UnderlineStyle.NO_UNDERLINE);
		timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
		// Lets automatically wrap the cells
		// timesBoldUnderline.setWrap(true);
		sheet.getSettings().setVerticalFreeze(1);
		CellView cv = new CellView();
		cv.setFormat(times);
		cv.setFormat(timesBoldUnderline);
		// cv.setAutosize(true);
		cv.setSize(25 * 8);
		// Write a few headers
		for (int i = 1; i < 8; i++) {
			// First column
			addCaption(sheet, i - 1, 0, "A" + i);
			addCaption(sheet, 7 + i, 0, "B" + i);
			addCaption(sheet, 15 + i, 0, "C" + i);
			addCaption(sheet, 23 + i, 0, "D" + i);

		}
		cv.setSize(10 * 200);
		addCaption(sheet, 32, 0, "Time");
		System.out.println(cv.getSize());

	}

	public void addCaption(WritableSheet sheet, int column, int row, String s)
			throws RowsExceededException, WriteException {
		Label label;
		label = new Label(column, row, s, times);
		sheet.addCell(label);
	}
}
