/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package eldercare.Display;

import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author kishor
 */
public class GraphWindow extends JFrame{

    GraphWindow(ElderCareView ed) {
        this.ed=ed;
        Container c=getContentPane();
        JPanel pan= new TableDemo(ed);
        add(pan);
        setSize(800,800);
        setVisible(true);




    }

   ElderCareView ed;
}
