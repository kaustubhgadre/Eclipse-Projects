/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package eldercare.Display;

/**
 *
 * @author eldercare
 */
import java.io.File;
import java.io.IOException;
import java.util.Locale;

import jxl.CellView;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.format.UnderlineStyle;
import jxl.write.Formula;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;


public class WriteExcel {


        WriteExcel(String filename)
        {
            this.filename=filename;
        }

	public void initialwrite() throws IOException, WriteException {
		file = new File(filename);
		wbSettings = new WorkbookSettings();
                wbSettings.setEncoding("UTF-8");
		//wbSettings.setLocale(new Locale("en", "EN"));
                //wbSettings.setCharacterSet(cs)

		workbook = Workbook.createWorkbook(file, wbSettings);
		workbook.createSheet("Report", 0);
		excelSheet = workbook.getSheet(0);
		createLabel(excelSheet);
//		createContent(excelSheet);

		workbook.write();
//		workbook.close();
	}

	public void mywrite() throws IOException, WriteException {

		createLabel1(excelSheet);
//		createContent(excelSheet);

		//workbook.write();
//		workbook.close();
	}
	public void createLabel1(WritableSheet sheet)
			throws WriteException {
		// Lets create a times font
		WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
		// Define the cell format
		times = new WritableCellFormat(times10pt);
		// Lets automatically wrap the cells
		times.setWrap(true);

		// Create create a bold font with unterlines
		WritableFont times10ptBoldUnderline = new WritableFont(
				WritableFont.TIMES, 10, WritableFont.BOLD, false,
				UnderlineStyle.NO_UNDERLINE);
		timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
		// Lets automatically wrap the cells
		timesBoldUnderline.setWrap(true);

		CellView cv = new CellView();
		cv.setFormat(times);
		cv.setFormat(timesBoldUnderline);
		cv.setAutosize(true);

		// Write a few headers
		for (int i = 1; i < 8; i++) {
			// First column
        		addCaption(sheet, i-1,1, "A"+i);
                	addCaption(sheet,  6+i, 1,"B"+i);
                        addCaption(sheet, 13+i,1, "C"+i);

		}
        }

	public void createLabel(WritableSheet sheet)
			throws WriteException {
		// Lets create a times font
		WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
		// Define the cell format
		times = new WritableCellFormat(times10pt);
		// Lets automatically wrap the cells
		times.setWrap(true);

		// Create create a bold font with unterlines
		WritableFont times10ptBoldUnderline = new WritableFont(
				WritableFont.TIMES, 10, WritableFont.BOLD, false,
				UnderlineStyle.NO_UNDERLINE);
		timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
		// Lets automatically wrap the cells
		timesBoldUnderline.setWrap(true);

		CellView cv = new CellView();
		cv.setFormat(times);
		cv.setFormat(timesBoldUnderline);
		cv.setAutosize(true);

		// Write a few headers
		for (int i = 1; i < 8; i++) {
			// First column
        		addCaption(sheet, i-1,0, "A"+i);
                	addCaption(sheet,  6+i, 0,"B"+i);
                        addCaption(sheet, 13+i,0, "C"+i);

		}

		

	}

	public void createContent(WritableSheet sheet) throws WriteException,
			RowsExceededException,
			IOException {
		// Write a few number
		for (int i = 1; i < 10; i++) {
			// First column
			addNumber(sheet, 0, i, i + 10);
			// Second column
			addNumber(sheet, 1, i, i * i);
		}
		// Lets calculate the sum of it
		StringBuffer buf = new StringBuffer();
		buf.append("SUM(A2:A10)");
		Formula f = new Formula(0, 10, buf.toString());
		sheet.addCell(f);
		buf = new StringBuffer();
		buf.append("SUM(B2:B10)");
		f = new Formula(1, 10, buf.toString());
		sheet.addCell(f);

		// Now a bit of text
		for (int i = 12; i < 20; i++) {
			// First column
			addLabel(sheet, 0, i, "Boring text " + i);
			// Second column
			addLabel(sheet, 1, i, "Another text");
		}
	}

	public void addCaption(WritableSheet sheet, int column, int row, String s)
			throws RowsExceededException, WriteException {
		Label label;
		label = new Label(column, row, s, timesBoldUnderline);
		sheet.addCell(label);
	}
        public void writeNumber(int column, int row, Integer integer) throws 
                WriteException, RowsExceededException, IOException
        {
            excelSheet = workbook.getSheet(0);
		Number number;
		number = new Number(column, row, integer, times);
		excelSheet.addCell(number);
                workbook.write();
            
        }

	public void addNumber(WritableSheet sheet, int column, int row,
			Integer integer) throws WriteException, RowsExceededException, IOException {
		Number number;
		number = new Number(column, row, integer, times);
		sheet.addCell(number);
                workbook.write();
	}

	public void addLabel(WritableSheet sheet, int column, int row, String s)
			throws WriteException, RowsExceededException {
		Label label;
		label = new Label(column, row, s, times);
		sheet.addCell(label);
	}

/*	public static void main(String[] args) throws WriteException, IOException {
		WriteExcel test = new WriteExcel();
		test.setOutputFile("c:/temp/lars.xls");
		test.write();
		System.out
				.println("Please check the result file under c:/temp/lars.xls ");
	}*/
public WritableCellFormat timesBoldUnderline;
public WritableCellFormat times;
public String filename;
public WritableWorkbook workbook ;
public  WritableSheet excelSheet;
public File file;
public WorkbookSettings wbSettings;

}



