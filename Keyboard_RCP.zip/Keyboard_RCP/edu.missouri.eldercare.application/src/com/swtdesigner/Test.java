package com.swtdesigner;

import gnu.io.CommPortIdentifier;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Random;

import jxl.CellView;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.format.Alignment;
import jxl.format.CellFormat;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.ui.PlatformUI;

public class Test {

	public static void main(String[] args) {/*
		// String userDir = getInstallationDirectory();
		WorkbookSettings wbSettings = new WorkbookSettings();
		wbSettings.setEncoding("UTF-8");
		wbSettings.setLocale(new Locale("en", "US"));

		File file = new File("C:\\temp\\temporary.xls");
		WritableWorkbook workbook = null;
		try {
			workbook = Workbook.createWorkbook(file, wbSettings);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		workbook.createSheet("Area A", 0);
		workbook.createSheet("Area B", 1);
		workbook.createSheet("Area C", 2);
		workbook.createSheet("Area D", 3);

		WritableSheet[] excelSheets = workbook.getSheets();
		for (int i = 0; i < excelSheets.length; i++) {
			try {
				createLabel(excelSheets[i]);
			} catch (WriteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		try {
			workbook.write();
			workbook.close();
		} catch (WriteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	*/
		char c = 'A';
		String str = "A";
		Integer tempinteger = (int) c;
		System.out.println("Integer "+(int)(str.charAt(0)));
		System.out.println("c");
		String binaryString = Integer.toBinaryString('2');
		int parseInt = Integer.parseInt(binaryString);
		System.out.println("Inttobin "+binaryString+" bintoint "+str.substring(2));
		Random gen = new Random();
		for (int i = 0; i < 10; i++) {
			System.out.println(gen.nextInt(9));
		}
		}

	public static void createLabel(WritableSheet sheet) throws WriteException {
		// Define the cell format
		WritableCellFormat times = new WritableCellFormat(new WritableFont(
				WritableFont.TIMES, 10, WritableFont.BOLD));
		// Lets automatically wrap the cells
		// times.setWrap(true);
		times.setAlignment(Alignment.CENTRE);
		// Create create a bold font with unterlines
		WritableCellFormat timesBoldUnderline = new WritableCellFormat(
				new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD,
						false, UnderlineStyle.NO_UNDERLINE));
		// Lets automatically wrap the cells
		// timesBoldUnderline.setWrap(true);
		sheet.getSettings().setVerticalFreeze(1);
		CellView cv = new CellView();
		cv.setFormat(times);
		cv.setFormat(timesBoldUnderline);
		// cv.setAutosize(true);
		cv.setSize(25 * 8);
		// Write a few headers

		for (int i = 1; i <= 8; i++) {
			addLabel(sheet, i - 1, 0, "A" + i, times);
			addLabel(sheet, 7 + i, 0, "B" + i, times);
			addLabel(sheet, 15 + i, 0, "C" + i, times);
			addLabel(sheet, 23 + i, 0, "D" + i, times);
		}
		cv.setSize(10 * 200);
		addLabel(sheet, 32, 0, "Time", times);
	}
	

	public static void addLabel(WritableSheet sheet, int column, int row,
			String s, WritableCellFormat format) throws WriteException,
			RowsExceededException {
		Label label;
		label = new Label(column, row, s, format);
		sheet.addCell(label);
	}

	public static IPath getPlatformPath() {
		URL platformInstallationURL = Platform.getInstallLocation().getURL();
		String platformInstallationPath = platformInstallationURL.getPath();
		IPath newInstallationPath = new Path(platformInstallationPath);
		return newInstallationPath;
	}

	// Get platform path
	public static String getPlatformPathString() {
		URL platformInstallationURL = Platform.getInstallLocation().getURL();
		String platformInstallationPath = platformInstallationURL.getPath();
		return platformInstallationPath;
	}

	// Get installation path of corona
	public static String getInstallationDirectory() {
		IPath newInstallationPath = getPlatformPath();
		IPath installationDirectory = newInstallationPath.removeLastSegments(1);
		String platformInstallationDir = installationDirectory.toString();
		return platformInstallationDir;
	}
}
