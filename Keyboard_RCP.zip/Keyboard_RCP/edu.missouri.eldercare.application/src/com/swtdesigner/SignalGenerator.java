package com.swtdesigner;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Random;

public final class SignalGenerator {
	public static void main(String args[]) {
		try {
			FileWriter fstream = new FileWriter("C:/temp/signal.txt");
			BufferedWriter out = new BufferedWriter(fstream);
			//out.write("SABCDE");
			for (int i = 0; i < 1000; i++) {
				String a = getRandomNumber();
				String b = getRandomNumber();
				String c = getRandomNumber();
				String d = getRandomNumber();
				out.append("SA"+a+"B"+b+"C"+c+"D"+d+"E");
				out.newLine();
			}
			
			// Close the output stream
			out.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	private static String getRandomNumber() {
		Random gen = new Random();
		String result = "";
		for (int i = 0; i < 8; i++) {
			int value = gen.nextInt(9);
			result = result + value;
		}
		return result;
	}
}
