package edu.missouri.eldercare.application;

import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.ICoolBarManager;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.ToolBarContributionItem;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;
import org.eclipse.ui.internal.about.AboutAction;

import edu.missouri.eldercare.application.actions.RunAction;
import edu.missouri.eldercare.application.actions.ShowHistogramAction;
import edu.missouri.eldercare.application.actions.ShowStatisticsAction;

public class ApplicationActionBarAdvisor extends ActionBarAdvisor {

	private IWorkbenchAction exitAction;
	private IWorkbenchAction helpContentsAction;
	private AboutAction aboutAction;
	private RunAction runProgramAction;
	private ShowHistogramAction showHistogramAction;
	private ShowStatisticsAction showStatisticsAction;

	public ApplicationActionBarAdvisor(IActionBarConfigurer configurer) {
		super(configurer);
	}

	protected void makeActions(IWorkbenchWindow window) {
		exitAction = ActionFactory.QUIT.create(window);
		register(exitAction);

		runProgramAction = new RunAction();
		runProgramAction.setText("Run");
		runProgramAction.setAccelerator(SWT.CTRL|'R');
		
		
		showStatisticsAction = new ShowStatisticsAction();
		showStatisticsAction.setText("Show Statistics");
		register(showStatisticsAction); 

		
		showHistogramAction = new ShowHistogramAction();
		showHistogramAction.setText("Show Histogram");
		register(showHistogramAction); 

		
		helpContentsAction = ActionFactory.HELP_CONTENTS.create(window);
		register(helpContentsAction);

		aboutAction = new AboutAction(window);
		register(aboutAction);
		aboutAction.setAccelerator(SWT.Help);
	}

	@Override
	protected void fillCoolBar(ICoolBarManager coolBar) {
		// TODO Auto-generated method stub
		super.fillCoolBar(coolBar);
		IToolBarManager toolbar = new ToolBarManager(SWT.FLAT | SWT.RIGHT);
		coolBar.add(new ToolBarContributionItem(toolbar, "main"));
		toolbar.add(runProgramAction);
	}

	protected void fillMenuBar(IMenuManager menuBar) {
		MenuManager fileMenu = new MenuManager(
				"&File", IWorkbenchActionConstants.M_FILE); //$NON-NLS-1$
		MenuManager helpMenu = new MenuManager(
				"&Help", IWorkbenchActionConstants.M_HELP); //$NON-NLS-1$

		menuBar.add(fileMenu);
		menuBar.add(helpMenu);

		GroupMarker fileStart = new GroupMarker("fileStart");
		fileMenu.add(fileStart);
		fileMenu.add(runProgramAction);
		fileMenu.add(showStatisticsAction);
		fileMenu.add(showHistogramAction);
		Separator exitStart = new Separator();
		fileMenu.add(exitStart);
		fileMenu.add(exitAction);
		helpMenu.add(aboutAction);
	}
}
