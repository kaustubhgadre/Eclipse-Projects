package edu.missouri.eldercare.application.ui;

import java.io.File;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.ole.win32.OleClientSite;
import org.eclipse.swt.ole.win32.OleFrame;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class HistogramDialog extends Dialog {

	protected Object result;
	protected Shell shlStatistics;
	private OleClientSite clientSite;

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public HistogramDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shlStatistics.setMaximized(true);
		shlStatistics.open();
		shlStatistics.layout();
		Display display = getParent().getDisplay();
		while (!shlStatistics.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shlStatistics = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MAX | SWT.APPLICATION_MODAL);
		shlStatistics.setSize(450, 300);
		shlStatistics.setText("Statistics");
		shlStatistics.setLayout(new GridLayout(1, false));
		OleFrame frame = new OleFrame(shlStatistics, SWT.NO_BACKGROUND);
		frame.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		frame.setLayout(new GridLayout(1, false));
		OleClientSite site = new OleClientSite(frame, SWT.NO_BACKGROUND, "Excel.Sheet", new File("C:/temp/temporary.xls"));
		site.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		site.setFocus();
	}

}
