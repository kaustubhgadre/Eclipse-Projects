package edu.missouri.eldercare.application.actions;

import java.util.Scanner;
 
public class Sleep{
	public static void main(String[] args) throws InterruptedException{
		Scanner input = new Scanner(System.in);
		int ms = input.nextInt(); //Java's sleep method accepts milliseconds
		System.out.println("Sleeping...");
		Thread.sleep(ms);
		System.out.println("Awake!");
	}
}