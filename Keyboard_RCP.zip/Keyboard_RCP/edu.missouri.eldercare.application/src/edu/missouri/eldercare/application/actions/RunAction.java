/**
 * 
 */
package edu.missouri.eldercare.application.actions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Locale;

import javax.activation.DataHandler;

import jxl.Cell;
import jxl.CellView;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.format.Alignment;
import jxl.format.UnderlineStyle;
import jxl.read.biff.BiffException;
import jxl.write.DateFormat;
import jxl.write.DateTime;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import edu.missouri.eldercare.application.handlers.ExcelHandler;
import edu.missouri.eldercare.application.utilities.CommonUtilities;
import edu.missouri.eldercare.application.views.ElderCareView;
import gnu.io.CommPortIdentifier;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;

/**
 * @author Kaustubh
 * 
 */
public class RunAction extends Action implements IWorkbenchAction {

	private static final String ID = "edu.missouri.eldercare.application.actions.RunAction";
	private Enumeration portList;
	private String display_data = "";
	private boolean data_started = false;
	private boolean data_ended = false;
	private IStatusLineManager statusLineManager;
	private IViewPart elderCareView;
	private ExcelHandler xlsHandler;
	private DataHandler dataHandler;

	/**
	 * 
	 */
	public RunAction() {
		setId(ID);
	}

	/**
	 * @param text
	 */
	public RunAction(String text) {
		super(text);
		setId(ID);
	}

	/**
	 * @param text
	 * @param image
	 */
	public RunAction(String text, ImageDescriptor image) {
		super(text, image);
	}

	@Override
	public void run() {
		// portList = CommPortIdentifier.getPortIdentifiers();
		elderCareView = PlatformUI.getWorkbench().getActiveWorkbenchWindow()
				.getActivePage().findView(ElderCareView.VIEW_ID);
		statusLineManager = elderCareView.getViewSite().getActionBars()
				.getStatusLineManager();
		String userDir = CommonUtilities.getInstallationDirectory();
		String systemLocale = System.getProperty("osgi.nl");
		WorkbookSettings wbSettings = new WorkbookSettings();
		wbSettings.setLocale(new Locale(systemLocale));
		String encoding = System.getProperty("file.encoding");
		wbSettings.setEncoding("UTF-8");
		File file = new File(userDir + "/temp/temporary.xls");
		xlsHandler = new ExcelHandler(wbSettings, file);

		if (!file.exists()) {
			xlsHandler.createExcel();

		}
		try {
			xlsHandler.removeSummation();
		} catch (BiffException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (WriteException e) {
			e.printStackTrace();
		}
		//dataHandler = new DataHandler(xlsHandler);
		File generator = new File(userDir + "/temp/signal.txt");
		byte[] readBuffer = new byte[8];
		FileInputStream fin;
		try {
			fin = new FileInputStream(generator);
			while (fin.available() > 0) {
				int numBytes = fin.read(readBuffer);
				String frameData = new String(readBuffer);
				processFrameData(frameData, numBytes, file, wbSettings);
			}
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			xlsHandler.addSummation();
		} catch (WriteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/*
		 * while (portList.hasMoreElements()) { CommPortIdentifier portId =
		 * (CommPortIdentifier) portList.nextElement(); if (portId.getPortType()
		 * == CommPortIdentifier.PORT_SERIAL) { if
		 * (portId.getName().equals("COM6")) { // if
		 * (portId.getName().equals("/dev/term/a")) { ReadData(portId); } } }
		 */
	}

	private void processFrameData(String frameData, int numBytes, File file,
			WorkbookSettings wbSettings) {
		for (int n = 0; n < numBytes; n++) {
			char current_data = (char) frameData.charAt(n);
			if (!data_started) {
				data_ended = false;
				if (display_data.endsWith("SA")) {
					data_started = true;
					display_data = "SA";
				} else

					display_data = display_data + current_data;
			}

			if (data_started) {
				display_data = display_data + current_data;

				if (data_started && !data_ended && display_data.endsWith("E")) {
					data_started = false;
					data_ended = true;
					processDisplayData(display_data, file, wbSettings);
					display_data = "";
				}
			}

		}
	}

	private void processDisplayData(String displayData, File file,
			WorkbookSettings wbsSettings) {
		int[] finalData = new int[128];
		if (!displayData.equals("SABCDE")) {
			int n = 0;
			for (int k = 1; k < displayData.length(); k++) {
				if (displayData.charAt(k) == 'A'
						|| displayData.charAt(k) == 'B'
						|| displayData.charAt(k) == 'C'
						|| displayData.charAt(k) == 'D') {
					continue;

				}
				if (displayData.charAt(k) == 'E') {
					k = 100;
					break;
				}
				String str1 = Integer.toBinaryString(displayData.charAt(k));
				String str2 = str1.substring(2);
				for (int i = 0; i < 4; i++) {
					if (n * 4 + i > 127)
						break;
					switch (str2.charAt(i)) {

					case '1':
						finalData[n * 4 + i] = 1;
						break;
					case '0':
						finalData[n * 4 + i] = 0;
						break;
					default:
						break;
					}

				}
				n++;
			}
		}
		try {
			showData(finalData, file, wbsSettings);
		} catch (RowsExceededException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (WriteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		((ElderCareView) elderCareView).redraw();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void showData(int[] finalData, File file,
			WorkbookSettings wbSettings) throws RowsExceededException,
			WriteException, IOException, BiffException {

		Workbook wb = Workbook.getWorkbook(file);
		WritableWorkbook workbook = Workbook.createWorkbook(file, wb);
		if (elderCareView instanceof ElderCareView) {
			org.eclipse.swt.widgets.Label[] labels = ((ElderCareView) elderCareView)
					.getChildren();
			for (int i = 0; i < finalData.length; i++) {
				String value = Integer.toString(finalData[i]);
				if (finalData[i] == 1) {
					labels[i].setBackground(new Color(null, 237, 28, 36));
					Composite parent = labels[i].getParent();
					if (parent instanceof Canvas) {
						Canvas canvas = (Canvas) parent;
						canvas.setBackground(new Color(null, 237, 28, 36));
						writeIntoExcel(workbook, labels[i], i, value);
					}
				} else {
					Color backGroundColor = (Color) labels[i]
							.getData("greenBack");
					labels[i].setBackground(backGroundColor);
					Composite parent = labels[i].getParent();
					if (parent instanceof Canvas) {
						Canvas canvas = (Canvas) parent;
						canvas.setBackground(backGroundColor);
						// writeIntoExcel(workbook, labels[i], i, value);
					}
				}
			}
		}
		workbook.write();
		workbook.close();
	}

	private void addSummation(WritableWorkbook workbook) throws WriteException {
		WritableCellFormat times = new WritableCellFormat(new WritableFont(
				WritableFont.TIMES, 10, WritableFont.BOLD));
		times.setAlignment(Alignment.CENTRE);
		CellView cv = new CellView();
		cv.setFormat(times);
		WritableSheet[] sheets = workbook.getSheets();

		for (int i = 0; i < sheets.length; i++) {
			WritableSheet writableSheet = sheets[i];
			int rows = writableSheet.getRows();
			for (int j = 0; j < 32; j++) {
				Cell[] column = writableSheet.getColumn(j);
				int sum = 0;
				for (int k = 1; k < column.length; k++) {
					String contents = column[k].getContents();
					sum = sum + Integer.parseInt(contents);
				}
				if (rows > 1)
					addLabel(writableSheet, j, rows + 1, Integer.toString(sum),
							times);
			}

		}
	}

	private void writeIntoExcel(WritableWorkbook workbook,
			org.eclipse.swt.widgets.Label label, int index, String value)
			throws RowsExceededException, WriteException,
			NumberFormatException, IOException {
		Composite parent = ((Canvas) label.getParent()).getParent();
		String areaName = (String) parent.getData("name");
		int worksheetNum = (int) areaName.charAt(0) - 65;
		WritableSheet writableSheet = workbook.getSheets()[worksheetNum];
		int rows = writableSheet.getRows();
		WritableCellFormat timesZero = new WritableCellFormat(new WritableFont(
				WritableFont.TIMES, 10, WritableFont.NO_BOLD));
		WritableCellFormat timesOne = new WritableCellFormat(new WritableFont(
				WritableFont.TIMES, 10, WritableFont.BOLD));
		timesZero.setAlignment(Alignment.CENTRE);
//		timesZero.setBackground(Colour.LIGHT_ORANGE, Pattern.GRAY_75);
		timesOne.setAlignment(Alignment.CENTRE);
	//	timesOne.setBackground(Colour.LIGHT_GREEN);

		CellView cv = new CellView();
		cv.setFormat(timesOne);
		((ElderCareView)elderCareView).setStatusLine("Area "+areaName+" Block "+label.getText());
		// ((ElderCareView)elderCareView).redraw();
		if (index >= 0 && index < 32) {
			xlsHandler.addNumber(writableSheet, index, rows, Integer
					.parseInt(value), timesOne);
			addAllZeros(writableSheet, index, rows, "0", timesZero);
		} else if (index >= 32 && index < 64) {
			xlsHandler.addNumber(writableSheet, index - 32, rows, Integer
					.parseInt(value), timesOne);
			addAllZeros(writableSheet, index - 32, rows, "0", timesZero);

		} else if (index >= 64 && index < 96) {
			xlsHandler.addNumber(writableSheet, index - 64, rows, Integer
					.parseInt(value), timesOne);
			addAllZeros(writableSheet, index - 64, rows, "0", timesZero);

		} else if (index >= 96 && index < 128) {
			xlsHandler.addNumber(writableSheet, index - 96, rows, Integer
					.parseInt(value), timesOne);
			addAllZeros(writableSheet, index - 96, rows, "0", timesZero);
		}
		/*
		 * SimpleDateFormat dateFormat = new SimpleDateFormat(
		 * "EEE, d MMM yyyy HH:mm:ss");
		 */
		DateFormat dateFormat = new DateFormat("H:mm:ss");
		WritableCellFormat dateCellFormat = new WritableCellFormat(dateFormat);
		Date now = Calendar.getInstance().getTime();
		DateTime dateCell = new DateTime(32, rows, now, dateCellFormat);
		writableSheet.addCell(dateCell);
	}

	private void addAllZeros(WritableSheet writableSheet, int exceptColumn,
			int row, String value, WritableCellFormat times)
			throws RowsExceededException, WriteException,
			NumberFormatException, IOException {
		int columns = writableSheet.getColumns();
		for (int j = 0; j < columns - 1; j++) {
			if (j != exceptColumn)
				xlsHandler.addNumber(writableSheet, j, row, Integer
						.parseInt(value), times);
		}

	}

	private void ReadData(CommPortIdentifier portId) {
		try {
			SerialPort serialPort = (SerialPort) portId.open("ElderCare", 2000);
			InputStream inputStream = serialPort.getInputStream();
		} catch (PortInUseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void createLabel(WritableSheet sheet) throws WriteException {
		// Define the cell format
		WritableCellFormat times = new WritableCellFormat(new WritableFont(
				WritableFont.TIMES, 10, WritableFont.BOLD));
		// Lets automatically wrap the cells
		// times.setWrap(true);
		times.setAlignment(Alignment.CENTRE);
		// Create create a bold font with unterlines
		WritableCellFormat timesBoldUnderline = new WritableCellFormat(
				new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD,
						false, UnderlineStyle.NO_UNDERLINE));
		// Lets automatically wrap the cells
		// timesBoldUnderline.setWrap(true);
		sheet.getSettings().setVerticalFreeze(1);
		CellView cv = new CellView();
		cv.setFormat(times);
		cv.setFormat(timesBoldUnderline);
		// cv.setAutosize(true);
		cv.setSize(25 * 8);
		// Write a few headers

		for (int i = 1; i <= 8; i++) {
			addLabel(sheet, i - 1, 0, "A" + i, times);
			addLabel(sheet, 7 + i, 0, "B" + i, times);
			addLabel(sheet, 15 + i, 0, "C" + i, times);
			addLabel(sheet, 23 + i, 0, "D" + i, times);
		}
		cv.setSize(10 * 200);
		addLabel(sheet, 32, 0, "Time", times);
	}

	public static void addLabel(WritableSheet sheet, int column, int row,
			String s, WritableCellFormat format) throws WriteException,
			RowsExceededException {
		Label label;
		label = new Label(column, row, s, format);
		sheet.addCell(label);
	}

	public RunAction(String text, String id) {
		setText(text);
		setId(id);
		setAccelerator(SWT.CTRL | 'R');
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.actions.ActionFactory.IWorkbenchAction#dispose()
	 */
	public void dispose() {
		// TODO Auto-generated method stub

	}
}
