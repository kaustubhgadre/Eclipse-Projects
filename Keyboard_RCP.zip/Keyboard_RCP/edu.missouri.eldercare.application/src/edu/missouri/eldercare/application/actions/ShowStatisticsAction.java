/**
 * 
 */
package edu.missouri.eldercare.application.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import edu.missouri.eldercare.application.ui.HistogramDialog;
import edu.missouri.eldercare.application.ui.StatiscticsDialog;

/**
 * @author Kaustubh
 * 
 */
public class ShowStatisticsAction extends Action implements IWorkbenchAction {

	private static final String ID = "edu.missouri.eldercare.application.actions.ShowStatisticsAction";

	@Override
	public void run() {
		StatiscticsDialog dialog = new StatiscticsDialog(Display.getDefault()
				.getActiveShell());
		dialog.open();
	}

	public ShowStatisticsAction() {
		setId(ID);
	}

	public ShowStatisticsAction(String text, ImageDescriptor image) {
		super(text, image);
		// TODO Auto-generated constructor stub
	}

	public ShowStatisticsAction(String text, int style) {
		super(text, style);
		// TODO Auto-generated constructor stub
	}

	public ShowStatisticsAction(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.actions.ActionFactory.IWorkbenchAction#dispose()
	 */
	public void dispose() {
		// TODO Auto-generated method stub

	}

}
